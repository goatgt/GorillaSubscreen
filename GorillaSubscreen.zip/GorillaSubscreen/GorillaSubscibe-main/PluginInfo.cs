﻿namespace Subscribe
{
	class PluginInfo
	{
		public const string GUID = "com.subscribe.gorillatag.Subscribe";
		public const string Name = "Subscribe";
		public const string Version = "1.0.0";
	}
}